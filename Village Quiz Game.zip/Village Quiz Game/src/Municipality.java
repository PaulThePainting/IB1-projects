import java.sql.*;

public class Municipality {
    int id;
    String name;

    public Municipality(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public Municipality(ResultSet resultSet) throws SQLException {
        this.id = resultSet.getInt("ID");
        this.name = resultSet.getString("Pavadinimas");
    }
}
