import java.sql.*;

public class DatabaseManager {
    private String dbUrl;

    public DatabaseManager(String dbFilePath) {
        this.dbUrl = "jdbc:sqlite:" + dbFilePath;
    }

    public Connection getConnection() {
        Connection conn = null;
        try {
            // Set character encoding to UTF-8
            DriverManager.registerDriver(new org.sqlite.JDBC());
            java.util.Properties properties = new java.util.Properties();
            properties.setProperty("characterEncoding", "UTF-8");
            properties.setProperty("useUnicode", "true");

            conn = DriverManager.getConnection(dbUrl, properties);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
}
