import java.sql.*;

public class Village {
    int id;
    String name;
    int municipalityId;

    public Village(int id, String name, int municipalityId) {
        this.id = id;
        this.name = name;
        this.municipalityId = municipalityId;
    }

    public Village(ResultSet resultSet) throws SQLException {
        this.id = resultSet.getInt("ID");
        this.name = resultSet.getString("Pavadinimas");
        this.municipalityId = resultSet.getInt("Savivaldybes_ID");
    }
}
