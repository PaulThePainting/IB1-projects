import java.sql.*;
import java.util.*;

public class VillageQuizGame {
    private static ArrayList<Village> loadVillages(DatabaseManager dbManager) {
        ArrayList<Village> villages = new ArrayList<>();
        String sql = "SELECT * FROM Village_list";

        try (Connection conn = dbManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet resultSet = stmt.executeQuery(sql)) {

            while (resultSet.next()) {
                Village village = new Village(resultSet);
                //System.out.println("Loaded village: " + village.name + ", Municipality ID: " + village.municipalityId); // Debug print
                villages.add(village);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return villages;
    }


    private static ArrayList<Municipality> loadMunicipalities(DatabaseManager dbManager) {
        ArrayList<Municipality> municipalities = new ArrayList<>();
        String sql = "SELECT * FROM Municipality_list";

        try (Connection conn = dbManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet resultSet = stmt.executeQuery(sql)) {

            while (resultSet.next()) {
                Municipality municipality = new Municipality(resultSet);
                //System.out.println("Loaded municipality: " + municipality.name + ", ID: " + municipality.id); // Debug print
                municipalities.add(municipality);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return municipalities;
    }


    public static void main(String[] args) {
        DatabaseManager dbManager = new DatabaseManager("Lithuanian_places.db");
        ArrayList<Village> villages = loadVillages(dbManager);
        ArrayList<Municipality> municipalities = loadMunicipalities(dbManager);
        Scanner scanner = new Scanner(System.in);

        int correctAnsCounter = 0;
        boolean isCorrect;
        String restart = "restart";
        int questionNum = 0;

        while (restart.equalsIgnoreCase("restart")) {
            System.out.println("How many questions do you want?");
            String input = scanner.nextLine();
            questionNum = questionNum + Integer.parseInt(input);
            for (int i = 0; i < Integer.parseInt(input); i++) {
                Village randomVillage = getRandomVillage(villages);
                Municipality correspondingMunicipality = findMunicipality(municipalities, randomVillage.municipalityId);
                List<Municipality> options = generateOptions(municipalities, correspondingMunicipality);
                displayQuestion(randomVillage, options);
                String guess = scanner.nextLine();
                int userAnswer = guess.toUpperCase().charAt(0) - 'A' + 1;
                isCorrect = getAnswer(userAnswer, options.indexOf(correspondingMunicipality));
                correctAnsCounter = answerCounter(isCorrect, correctAnsCounter);
            }

            System.out.println("You got " + correctAnsCounter + "/" + questionNum + " questions right!");
            System.out.println("Type 'restart' if you want to restart the game");
            restart = scanner.nextLine();
        }


    }

    private static Village getRandomVillage(ArrayList<Village> villages) {
        Random random = new Random();
        int randomIndex = random.nextInt(villages.size());
        return villages.get(randomIndex);
    }

    private static Municipality findMunicipality(ArrayList<Municipality> municipalities, int municipalityId) {
        //System.out.println("Looking for municipality with ID: " + municipalityId); // Debug print
        for (Municipality municipality : municipalities) {
            //System.out.println("Checking: " + municipality.id + " against " + municipalityId); // Debug print
            if (municipality.id == municipalityId) {
                //System.out.println("Found matching municipality: " + municipality.name); // Debug print
                return municipality;
            }
        }
        System.out.println("No matching municipality found for ID: " + municipalityId); // Debug print
        return null; // Return null if no matching municipality is found
    }



    private static Municipality getRandomMunicipality(ArrayList<Municipality> municipalities) {
        Random random = new Random();
        int randomIndex = random.nextInt(municipalities.size());
        return municipalities.get(randomIndex);
    }

    private static List<Municipality> generateOptions(ArrayList<Municipality> municipalities, Municipality correctMunicipality) {
        List<Municipality> options = new ArrayList<>(3);
        Random random = new Random();
        int answerIndex = random.nextInt(4);
        for (int i = 0; i < 4; i++) {
            if (i == answerIndex) {
                options.add(correctMunicipality);
            } else {
                options.add(getRandomMunicipality(municipalities));
            }
        }
        return options;
    }

    private static void displayQuestion(Village village, List<Municipality> options) {
        System.out.println("Which municipality does the village \"" + village.name + "\" belong to?");
        for (int i = 0; i < options.size(); i++) {
            System.out.println((char) ('A' + i) + ". " + options.get(i).name);
        }
    }

    private static boolean getAnswer(int input, int answer) {
        if (input == answer) {
            System.out.println("Correct!");
            return true;
        } else {
            System.out.println("Incorrect");
            return false;
        }
    }
    private static int answerCounter (boolean isCorrect, int count)
    {
        if (isCorrect)
        {
            count = count + 1;
        }
        return count;
    }
}

